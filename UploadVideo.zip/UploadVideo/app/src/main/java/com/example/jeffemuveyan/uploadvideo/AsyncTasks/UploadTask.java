package com.example.jeffemuveyan.uploadvideo.AsyncTasks;

import android.os.AsyncTask;

import com.example.jeffemuveyan.uploadvideo.MainActivity;

import java.net.URL;

import io.tus.java.client.TusClient;
import io.tus.java.client.TusUpload;
import io.tus.java.client.TusUploader;

public class UploadTask extends AsyncTask<Void, Long, URL> {
    private MainActivity activity;
    private TusClient client;
    private TusUpload upload;
    private Exception exception;

    public UploadTask(MainActivity activity, TusClient client, TusUpload upload) {
        this.activity = activity;
        this.client = client;
        this.upload = upload;
    }

    @Override
    protected void onPreExecute() {
        activity.setStatus("Upload selected...");
        activity.setPauseButtonEnabled(true);
        activity.setUploadProgress(0);
    }

    @Override
    protected void onPostExecute(URL uploadURL) {
        activity.setStatus("Upload finished!\n" + uploadURL.toString());
        activity.setPauseButtonEnabled(false);
    }

    @Override
    protected void onCancelled() {
        if(exception != null) {
            activity.showError(exception);
        }

        activity.setPauseButtonEnabled(false);
    }

    @Override
    protected void onProgressUpdate(Long... updates) {
        long uploadedBytes = updates[0];
        long totalBytes = updates[1];
        activity.setStatus(String.format("Uploaded %d/%d.", uploadedBytes, totalBytes));
        activity.setUploadProgress((int) ((double) uploadedBytes / totalBytes * 100));
    }

    @Override
    protected URL doInBackground(Void... params) {
        try {
            TusUploader uploader = client.resumeOrCreateUpload(upload);
            long totalBytes = upload.getSize();
            long uploadedBytes = uploader.getOffset();

            // Upload file in 1MiB chunks
            uploader.setChunkSize(1024 * 1024);

            while(!isCancelled() && uploader.uploadChunk() > 0) {
                uploadedBytes = uploader.getOffset();
                publishProgress(uploadedBytes, totalBytes);
            }

            uploader.finish();
            return uploader.getUploadURL();

        } catch(Exception e) {
            exception = e;
            cancel(true);
        }
        return null;
    }
}
