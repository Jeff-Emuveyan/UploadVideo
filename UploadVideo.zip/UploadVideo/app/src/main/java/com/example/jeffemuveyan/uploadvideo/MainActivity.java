package com.example.jeffemuveyan.uploadvideo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.provider.MediaStore.Video.Thumbnails;
import com.example.jeffemuveyan.uploadvideo.AsyncTasks.UploadTask;
import com.jaiselrahman.filepicker.activity.FilePickerActivity;
import com.jaiselrahman.filepicker.config.Configurations;
import com.jaiselrahman.filepicker.model.MediaFile;

import java.net.URL;
import java.util.ArrayList;

import io.tus.android.client.TusAndroidUpload;
import io.tus.android.client.TusPreferencesURLStore;
import io.tus.java.client.TusClient;
import io.tus.java.client.TusUpload;
import io.tus.java.client.TusUploader;


public class MainActivity extends AppCompatActivity {

    private static final int FILE_REQUEST_CODE = 33;
    ImageView imageView;
    Button chooseButton, uploadButton, pauseButton, resumeButton, cancelButton;
    TextView titleTextView, percentageTextView;
    ProgressBar progressBar;

    private final int REQUEST_FILE_SELECT = 1;
    private TusClient client;
    private Uri fileUri;

    UploadTask uploadTask;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView)findViewById(R.id.imageView);
        chooseButton = (Button)findViewById(R.id.button);
        uploadButton = (Button)findViewById(R.id.button2);
        pauseButton = (Button)findViewById(R.id.button3);
        cancelButton = (Button)findViewById(R.id.button4);
        resumeButton = (Button)findViewById(R.id.button5);
        titleTextView = (TextView) findViewById(R.id.textView);
        percentageTextView = (TextView) findViewById(R.id.textView2);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        //disable some views
        uploadButton.setEnabled(false);
        pauseButton.setVisibility(View.GONE);
        cancelButton.setVisibility(View.GONE);
        percentageTextView.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);


        chooseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                chooseVideo();
            }
        });


        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //uploadVideo();
            }
        });


        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseUpload();
            }
        });


        resumeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resumeUpload();
            }
        });


        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });


        try {
            SharedPreferences pref = getSharedPreferences("tus", 0);
            client = new TusClient();
            client.setUploadCreationURL(new URL("https://master.tus.io/files/"));
            client.enableResuming(new TusPreferencesURLStore(pref));
        } catch(Exception e) {
            showError(e);
        }

    }



    private void chooseVideo(){
        Intent intent = new Intent(this, FilePickerActivity.class);
        intent.putExtra(FilePickerActivity.CONFIGS, new Configurations.Builder()
                .setCheckPermission(true)
                .setShowImages(false)
                .setShowAudios(false)
                .setShowVideos(true)
                .enableImageCapture(true)
                .setMaxSelection(1)
                .setSkipZeroSizeFiles(true)
                .build());
        startActivityForResult(intent, FILE_REQUEST_CODE);
    }


    private void beginUpload(Uri uri) {
        fileUri = uri;
        resumeUpload();
    }


    private void pauseUpload(){
        uploadTask.cancel(false);
    }


    private void resumeUpload() {
        try {
            TusUpload upload = new TusAndroidUpload(fileUri, this);
            uploadTask = new UploadTask(this, client, upload);
            uploadTask.execute(new Void[0]);
        } catch (Exception e) {
            showError(e);
        }
    }



    public void setUploadProgress(int progress) {
        progressBar.setProgress(progress);
    }


    public void setPauseButtonEnabled(boolean b) {
        pauseButton.setEnabled(b);
        resumeButton.setEnabled(b);
    }

    public void setStatus(String text) {
        percentageTextView.setText(text);
    }


    public void showError(Exception e) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Internal error");
        builder.setMessage(e.getMessage());
        AlertDialog dialog = builder.create();
        dialog.show();
        e.printStackTrace();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        try {

            switch (requestCode) {

                case 33:
                    ArrayList<MediaFile> files = data.getParcelableArrayListExtra(FilePickerActivity.MEDIA_FILES);

                    MediaFile videoFile = files.get(0);//get the video file

                    //now display the video thumbnail
                    imageView.setImageBitmap(retrievThumbnailFromVideo(videoFile.getPath()));

                    Uri uri = data.getData();
                    beginUpload(uri);

                    break;
            }

            //NOTE: ALL THESES EXCEPTIONS ARE CAUSED BY THE LIBRARY WE ARE USING TO SELECT AUDIO. OUR OWN CODE IF 100% EXCELLENT
        }catch(IndexOutOfBoundsException e){// this exception occurs when the user pressing 'Done' when no song was selected
            showError(e);
        }catch(NullPointerException e){// this exception occurs when the user tries the go back from the audio picker
            //don't do anything
            showError(e);
        }catch(Exception e){// this exception occurs when the user tries the go back from the audio picker
            //don't do anything
            showError(e);
        }
    }

    public Bitmap retrievThumbnailFromVideo(String video_Path){

        Bitmap bitmap;

        bitmap = ThumbnailUtils.createVideoThumbnail(video_Path, Thumbnails.MINI_KIND);

        return bitmap;
    }


}
